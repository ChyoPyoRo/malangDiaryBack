declare function nameCheck(userId: string): Promise<import(".prisma/client").user | null>;
export { nameCheck };
