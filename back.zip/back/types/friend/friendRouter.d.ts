declare const friendRouter: import("express-serve-static-core").Router;
export { friendRouter };
