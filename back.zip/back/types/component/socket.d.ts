declare function setUpSocket(httpServer: object): void;
export { setUpSocket };
