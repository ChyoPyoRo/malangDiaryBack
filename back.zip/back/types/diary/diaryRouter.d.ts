declare const diaryRouter: import("express-serve-static-core").Express;
export { diaryRouter };
