declare const chatRouter: import("express-serve-static-core").Router;
export { chatRouter };
