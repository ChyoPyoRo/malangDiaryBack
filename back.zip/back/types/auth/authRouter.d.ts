declare const authRouter: import("express-serve-static-core").Router;
export { authRouter };
