declare const emotionRouter: import("express-serve-static-core").Express;
export { emotionRouter };
