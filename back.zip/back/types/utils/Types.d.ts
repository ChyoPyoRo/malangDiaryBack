export type emotion = "신이 난" | "편안한" | "감사한" | "자신감" | "불안" | "슬픔" | "분노" | "상처";
export type Scope = "all" | "friend" | "off";
