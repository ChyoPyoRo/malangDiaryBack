// import AWS from "aws-sdk";
// import { s3AccessKey, s3SecretKey, bucketName } from "./configModules";

// const storage: AWS.S3 = new AWS.S3({
//   accessKeyId: s3AccessKey,
//   secretAccessKey: s3SecretKey,
//   // region에 뭐가 들어가는지 확인해보기- 폴더이름인가 아님 버킷이름인가
//   region: bucketName,
// });

// export default storage;
